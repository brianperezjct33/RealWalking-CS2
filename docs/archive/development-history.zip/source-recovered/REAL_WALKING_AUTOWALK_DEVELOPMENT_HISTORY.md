# Real Walking / AutoWalk：研发与调试历史

> **记录范围**：本轮对话涉及的《城市：天际线 II》（Cities: Skylines II）第一人称步行探索及 **AutoWalk / FPC 道路读取研究分支**。  
> **整理日期**：2026-10-31。  
> **性质**：面向 GitHub 的研究记录（Development & Debugging History），不是已发布功能说明。  
> **特别说明**：本文件记录的是 `v0.x` 读路探针与 `G0/G1` 研究序列；它们与其他对话中可能存在的 Real Walking `RC` 发布候选版本属于不同的版本线，**不应把本分支的测试状态直接套用到 RC 版本**。

## 0. 真实性、贡献与状态标注

本项目在本轮研究中采用 **AI 辅助开发 + 用户本机验证** 的协作方式：需求、体验反馈、测试场景与路线决策由项目使用者提出或确认；ChatGPT 参与技术方案、C# 示例代码、PowerShell 构建脚本、故障分析和迭代文档的编写；实际 Windows 编译、游戏加载、快捷键操作及日志采集由用户完成。**AI 生成的源代码并不等同于已通过代码审查或实机验证。**

以下统一使用四类状态：

- **实机已验证**：有用户上传的 `Player.log` 提取记录或明确的本机成功反馈。
- **编译已验证**：有本机编译结果或用户明确反馈 `PASS`；不表示游戏内行为可用。
- **仅交付源码**：生成了压缩包/脚本，未收到相应的编译或运行结果。
- **方案/假设**：提出技术方向，尚无代码验证，不能作为已确认的游戏机制。

**截至本记录整理时：已经做到“从 CS2 查询部分真实车道数据”和“从正在运行的 First Person Camera Continued 读取自由镜头位置”；尚未证明天桥坡道可被正确识别，更没有在本分支中完成自动上、下坡的摄像机控制。**

## 1. 需求和约束的形成

目标不是普通的自由飞行相机，而是让玩家在游戏中以第一人称沿真实步行空间移动：支持 WASD、坡道与天桥高度跟随、防止上下层突然跳转，并在更远期考虑地下空间、站台和公共交通上下车。

用户明确提出的工程约束：

1. **优先复用既有模组**，尤其是 First Person Camera Continued（下称 FPC），避免重复实现相机、输入与实体跟随。
2. **避免安装完整 Unity / CS2 Modding Toolchain**，优先用 Windows 上的 .NET 8 SDK 和游戏安装目录的程序集完成轻量编译。
3. **主城市存档优先安全**：实验仅用于可丢弃的测试城市，不应覆盖 FPC 正式 DLL，不主动更改 ECS 城市实体或存档数据。
4. **低性能开销**：优先局部空间查询，避免遍历全城；记录扫描耗时，注意 `JobHandle.Complete()` 可能同步阻塞。
5. **先验证后集成**：道路高度数据未经确认前，不允许把相机吸附到所谓“最近”的车道。

## 2. 按版本的开发时间线

以下按照技术依赖和实际交流先后排序；压缩包版本名为交付名，并非全部已正式发布。部分包未有独立实机记录。

| 阶段/版本 | 开发目的与主要改动 | 可核验结果 | 状态 |
|---|---|---|---|
| 早期 Prototype | 直接修改 FPC 的 `ManualFinalTransform`，构想 `PedestrianSurfaceFollower` 和自动高度 | 提供源码补丁；无游戏编译/运行证据 | 仅交付源码 |
| Phase 1 / v0.1 | 脱离 CS2 编写步行核心、离线空间格网、车道锁定、拓扑检查、紧急恢复接口 | 对话中反馈离线测试通过；真实 CS2 接口与摄像机尚未接入 | 离线验证，不是游戏功能 |
| Phase 2A Probe | 计划通过官方工具链检查游戏道路 API | 提供探针方案，未成为最后采用的构建路线 | 方案/源码 |
| Phase 2A Lite / v0.2.0 | 改用 .NET 8 + 本机游戏 DLL，只通过反射读取 API | 最初结果仅记录 `Missing type: Game.Net.PathNode`；受日志级别过滤影响 | 局部实机记录 |
| **v0.2.1** | 将诊断改为 WARN 输出，纠正 `PathNode` 所属命名空间 | 确认 `SearchSystem`、`PedestrianLane`、`Lane`、`Curve`、`Game.Pathfind.PathNode` 和四叉树返回类型 | **实机已验证** |
| **v0.2.2** | 探测 `NativeQuadTree.Iterate` 泛型约束、接口及读者依赖 | 确认 `INativeQuadTreeIterator<...>` 约束与 `AddLaneSearchTreeReader(JobHandle)` 等签名 | **实机已验证** |
| v0.2.3 | 第一次尝试 ECS 道路空间索引实读 | 编译报 `CS0012`、`CS0115`；引用中包含不存在的 `Unity.Jobs.dll` | 编译失败 |
| v0.2.4 | 加入 `Colossal.Core.dll` 引用，移除错误的 `Unity.Jobs.dll` 引用 | 随后发现 `Time.realtimeSinceStartup` 被 ECS 的 `Time` 属性遮蔽，编译仍失败 | 编译失败后定位新问题 |
| **v0.2.5** | 改用 `UnityEngine.Time.realtimeSinceStartup`；完成真实局部车道读取 | 4次游戏扫描可取得实体、`PedestrianLane` 与 `Curve` 的高度信息 | **实机已验证** |
| **v0.2.6** | 增加55m精确距离过滤、贝塞尔曲线取样、坡度和耗时记录 | 5次自动扫描；部分位置找到5或9条行人曲线，`sloped55m=0` | **实机已验证** |
| **v0.2.7** | 改为按键启动10次、间隔2秒的手动扫描批次 | 快捷键与多批次扫描成功；27条采样记录没有发现满足阈值的坡道 | **实机已验证** |
| v0.2.8 Aim Probe | 改用镜头视线方向定点搜索，避免把俯视相机位置误当成观察目标 | 已交付源码；无对应运行日志 | 仅交付源码 |
| AutoWalk 方案 v1.0 | 技术路线调整为复用 FPC 相机和现有贴路算法 | 形成研发方案，没有新增实机能力 | 方案 |
| G0.1 Source Rebuild | 下载并轻量编译 FPC 的 C# 源码，输出隔离构建产物 | 本机 `BuildLog-G0.txt`：4个 `GetValueOrDefault` 相关 `CS1061`，125个警告 | 编译失败 |
| **G0.2 Compat Fix** | 不改上游源码，在隔离工程添加字典扩展兼容方法 | 用户明确反馈 **PASS** | **编译已验证**（不代表可安装） |
| **G1 / v0.3.0** | 独立 Bridge 模组读取 FPC 自由镜头位置，扫描脚下25m行人曲线 | 5次扫描均未找到距脚下3.5m内的合格人行车道 | **实机已验证** |
| **G1.1 / v0.3.1** | 对比 `GetLaneSearchTree(true/false)`，加入车/轨道/其他曲线及 FPC 高度偏移 | 3处位置两棵搜索树结果一致；仍无合格脚下人行车道 | **实机已验证** |
| G1.2 / v0.3.2 | 新增 `GetNetSearchTree` → `Edge/Node` → `SubLane` 的反向查询设计 | 已交付源码；截至目前未收到编译/游戏结果 | **仅交付源码** |

## 3. 关键开发与排错过程

### 3.1 从模拟步行算法转向真实游戏数据（Phase 1 → v0.2.2）

最初使用离线 `WalkingKernel` 和模拟空间网格建立高度连续性、路段锁定、连接检查以及异常恢复的框架。该设计避免直接写 ECS 存档数据，但**模拟路径的通过不能证明游戏天桥可行走**。

为避免直接猜测 CS2 内部 API，开发了仅反射读取元数据的 Lite 探针。第一次日志只出现 `Game.Net.PathNode` 缺失，随后发现信息级别日志未被完整采集，并不能把“未打印”解释为“接口不存在”。

v0.2.1 实机返回的关键签名：

```text
Game.Net.SearchSystem
GetLaneSearchTree(Boolean, ref Unity.Jobs.JobHandle)
-> Colossal.Collections.NativeQuadTree<Entity, Game.Common.QuadTreeBoundsXZ>
Game.Net.Curve.m_Bezier : Colossal.Mathematics.Bezier4x3
Game.Pathfind.PathNode   // 不在 Game.Net.PathNode
```

v0.2.2 又确认了 `Iterate<TIterator>(ref TIterator, int)` 的泛型约束，以及 `AddLaneSearchTreeReader(JobHandle)` 等读依赖接口。**这才为真实道路的局部读取提供了版本匹配的依据。**

### 3.2 轻量构建中的编译错误（v0.2.3 → v0.2.5）

第一版实际道路读取器没有一次编译成功，主要错误是：

- `CS0012`：遗漏 `Colossal.Core.dll` 依赖；伴随 `CS0115` 的系统覆盖方法识别错误。
- `MSB3245`：错误引用了本机没有的 `Unity.Jobs.dll`，该功能实际可由已有 Unity 引用满足。
- `CS0619` / `CS1061`：`ComponentSystemBase.Time` 与 `UnityEngine.Time` 名称冲突；改成完全限定的 `UnityEngine.Time.realtimeSinceStartup` 后解决。

v0.2.5 才得到实际游戏内扫描结果。四次扫描的已记录行人曲线数量分别为 **4、3、0、60**；所记录的路径高度范围依扫描位置变化。这证明了**查询确实返回了真实城市车道组件和三维曲线**，但并未证明扫描到的就是目标天桥。

### 3.3 为什么多次扫描仍未读到坡道（v0.2.6 → v0.2.8）

v0.2.6 将初筛的方形范围和严格的水平半径区别开来，增加曲线最近点、局部高度范围与单次耗时。5次自动扫描中的行人路径多数位于相机水平几十米外，`sloped55m` 均为0。用户指出：扫描启动太早，相机还没移动到待测坡道，固定次数已耗尽。

v0.2.7 据此增加 `Ctrl+Shift+L` 手动启动/重启、`Ctrl+Shift+K` 取消，以及每批10次、相隔约2秒的采样。实机日志证明输入和状态机正常：记录了 **3次启动、27次采样**（前两批完整，第三批记录至第7次）。局部扫描耗时大多约 **0.1–1.3ms**，但这些数字只覆盖测试环境中的测量范围，不能据此承诺大型城市零卡顿；而且 `JobHandle.Complete()` 仍可能造成同步等待。

这27次仍未发现满足该版坡度阈值的单条行人曲线。最接近的若干行人车道距相机水平约23–40米，说明**“相机所在位置”和“画面正在观察的位置”并不相同**。

v0.2.8 因此改为沿摄像机中心视线（最多约160m的多个局部采样点）寻找曲线，设计 `miss3D` 与 `aimed8m` 指标；**但此版本没有收到实机日志，不能宣称已解决定位问题。**

### 3.4 改变架构：优先使用成熟的 FPC（AutoWalk 方案 → G0.2）

经过比较后，项目决定优先利用现成 FPC 的 WASD、鼠标转向、手动高度、相机跟随及交通工具跟随，而不再重做一套相机系统。研究了在 FPC 的 `ManualFinalTransform` 高度计算处注入 AutoWalk 的方案，也参考了其他公开模组处理道路高度连续性的思路。

最初的 G0 阶段是**只重编译原模组 C# 部分**：不构建完整 UI，不覆盖正在使用的 FPC。`BuildLog-G0.txt` 报4处 `Dictionary<string,int>.GetValueOrDefault` 缺失，出现于 `FirstPersonCameraActivatedUISystem.cs` 的937、1171、1269、1449行；另有125条非阻断警告。

G0.2 在隔离工程补充兼容扩展方法，不直接修改上游快照。用户随后反馈 `PASS`，确认**轻量 C# 编译链可用**。但是，由于原仓库涉及完整 UI 资源、构建步骤和部署配置，这一阶段产物被明确放入 `dist-DO-NOT-INSTALL`，**未验证能够替代 Paradox Mods 中的完整 FPC 模组**。

随后进一步简化：G1 不立即覆盖/修改 FPC，而是作为独立、只读的 Bridge 模组，运行时读取已经安装的 FPC 控制器与相机位置。此选择减少了对现有模组的侵入性，但并不代表已接管镜头高度。

### 3.5 G1 的真实问题：能够读取镜头，却匹配不到脚下路径

G1 / v0.3.0 在 FPC 自由模式下测试5次，成功取得第一人称镜头位置（`freeFpcEye`）并进行25m局部车道查询。示例：

```text
freeFpcEye=(-1706.4,406.5,-3277.6)
footY~404.8
pedestrian25m=1
nearbyEligible=0
NEAR 1 xz=23.53m roadY=404.82
```

前3次的镜头高度约从406.5m升至412.4m，而识别到的最近行人路径高度一直约404.8m、水平距离仍约19–24m。**这不是自动上下坡成功，而是目标位置的有效路径匹配失败。**5次扫描均无符合“水平≤3.5m、估算垂直差≤3m”的候选。

G1.1 / v0.3.1 排查三种可能：是否搜索树布尔标志过滤了道路、是否脚下只有非行人曲线，以及镜头高度是否受 R/F 操作影响。

实机日志确认：

1. `GetLaneSearchTree(true)` 与 `false` 在3个采样位置返回了**相同的候选数、类型分布和最近距离**。故目前没有证据支持“改布尔参数就能找到遗漏的人行道”。
2. 第一处镜头水平2.71m处存在 `otherCurve`，3.46m处存在 `CarLane`，但邻近 `PedestrianLane` 仍距约22–23m；横向接近的非行人曲线**不能自动视为可步行**。
3. 第二处25m内没有识别到 `PedestrianLane`，存在若干道路曲线；第三处发现轨道与非行人曲线，且与估算脚底高度存在显著差异。
4. FPC 的 R/F 高度偏移分别为 **+3.00m、0.00m、−6.00m**。因此镜头 Y 高度的变化包含人为高度调整，不能据此证明坡道本身存在三维连续曲线。

**结论边界**：以上仅能说明当前搜索方式未找到目标脚下的合格 `PedestrianLane` / `ConnectionLane`；不能断言“游戏没有人行道”，也不能断言“天桥资产不可走”。

### 3.6 G1.2：从道路主体反查附属车道（尚未验证）

G1.2 / v0.3.2 的研究假设是：道路边缘的人行道或其他附属通道未必以之前采用的方式出现在车道树的邻近匹配中。为此交付了一个新读取方案：

```text
SearchSystem.GetNetSearchTree(...)
    -> nearby Edge / Node
    -> DynamicBuffer<SubLane>
    -> referenced lane entity
    -> PedestrianLane / ConnectionLane / Curve
```

同时保留原车道树输出作为对照，并增加 `NET-OWNERS`、`OWNER-PED` 等诊断项。该版的查询 API 及逻辑**仅按源码资料与设计实现，尚没有用户本机编译或运行日志**。因此不能把“已成功找到道路附属人行道”写入已完成成果。

用户最新提出的技术要求是：**在再次扩大诊断器之前，先从可靠来源核查路侧人行道、天桥、地铁/楼梯/站台在 CS2 中的真实导航类型、数据结构及查询入口，不再仅凭名称推断。** 截至本记录，尚未完成这一资料核查，也尚未证明 `SubLane` 就能覆盖这些场景。

## 4. 阶段性成果与未解决事项

### 已有证据支持的能力

- 可在本机通过轻量 .NET 工具链构建、安装和卸载独立的只读 CS2 测试 DLL。
- 已识别当前测试游戏程序集中的 `SearchSystem`、`GetLaneSearchTree`、四叉树迭代接口、`PedestrianLane`、`Curve` 和 `PathNode` 的具体命名空间。
- 已从真实城市数据中读取部分行人车道、贝塞尔曲线与高度范围；可统计局部查询耗时。
- 已通过 FPC 运行时桥接读取自由相机的当前位置及 R/F 高度偏移。
- G0.2 的 FPC C# 源码轻量重编译已得到用户 `PASS` 反馈。

### 尚未验证或尚未实现的能力

- 目标天桥坡道对应的正确导航类型与连续三维高度。
- 对普通道路**路侧**人行道、独立步行道、道路上的人行天桥，以及地铁入口、楼梯、地下通道、站台逐类建立有效查询方式。
- 正确解析 `SubLane`、导航 Area、隐藏路径、道路附属路径之间的关系及跨区域连接。
- 在上下层重叠处安全选择可行走高度、防跳层、碰撞与边缘约束。
- 将读取得到的高度正式写入 FPC 的相机运动流程。
- 自动上下天桥、地下空间自由步行、公共交通 E 键上/下车、完整 UI/配置与正式发布。

## 5. 研发方向的调整与原因

1. **从直接修改 FPC 到只读接口探针**：先核对游戏真实 API，避免错误调用。
2. **从官方完整工具链到轻量 .NET 构建**：降低用户环境门槛，保留原有游戏和模组文件。
3. **从固定自动采样到手动触发**：避免在进入测试城市的早期就耗尽采样机会。
4. **从俯视摄像机坐标到真实 FPC 坐标**：消除“镜头位置与观察目标位置不同”的一类混淆。
5. **从单一行人车道类型到全曲线/双树诊断**：确认不是简单的查询开关或 FPC 误调高导致的假象。
6. **从车道树查询转向道路主体关联/导航类型核查**：因为有明确证据显示普通车道曲线可被查询，目标脚下人行曲线却始终未匹配。
7. **推迟自动吸附**：不在缺少路面证据时把镜头强行吸到车道中心线，避免跨越数米甚至数十米跳层。

这些调整属于逐步排错；任何一种尚未实测的新路线都不应被描述为“问题已解决”。

## 6. 安全、性能与可重现性

- 所有测试版按设计采用只读的 `EntityManager`/`SearchSystem` 查询；**这只能说明源代码没有主动保存或写入城市实体，不能保证进程内 DLL 零崩溃或绝对不会损坏存档**。
- 实验须使用独立测试城市与 Playset，正式主存档应有独立备份。用户在测试结束后运行专用移除脚本。
- G0 产物不带完整 UI、没有作为成品安装；G1 作为独立桥接模组，不覆盖正式 FPC。
- 已记录的毫秒级耗时来自有限次数的局部采样；未在大城市、不同硬件、不同游戏更新版本上完成系统性能测试。
- `Game.Net.SearchSystem` 的结果依赖 ECS 作业状态，强制等待可能带来瞬时卡顿；以后需验证适当的 Job 依赖注册和非阻塞方式。
- 一旦游戏更新，应记录游戏构建号、FPC 版本、依赖 DLL、编译日志和测试地图配置；现有日志未完整保留这些元数据，不能假装已知。

## 7. 资料来源与可重现材料

以下是本轮研究实际使用/生成的**文件名**。它们是研究存档的索引，不能仅凭本表推断 GitHub 仓库已包含这些文件。发布到 GitHub 前应自行决定哪些源代码和脱敏日志适合入库。

| 研究节点 | 交付或证据文件 |
|---|---|
| 初期原型 | `CS2_RealWalking_Prototype.zip` |
| 离线内核 | `CS2_RealWalking_Phase1_Source.zip`、`CS2_RealWalking_Phase1_TestReady.zip` |
| 初期接口探针 | `CS2_RealWalking_Phase2A_Probe.zip`、`CS2_RealWalking_Phase2A_Lite.zip` |
| v0.2.1 | `CS2_RealWalking_Phase2A_Lite_v021.zip`、`RW-LITE-v021.txt` |
| v0.2.2 | `CS2_RealWalking_IteratorProbe_v022.zip`、`RW-LITE-v022.txt` |
| v0.2.3—0.2.5 | `CS2_RealWalking_LaneReader_v023.zip`、`...v024_BuildFix.zip`、`...v025_BuildFix.zip`、`BuildLog.txt`、`BuildLog(1).txt`、`RW-LITE-v025.txt` |
| v0.2.6 | `CS2_RealWalking_LaneReader_v026_GeometryProbe.zip`、`RW-LITE-v026.txt` |
| v0.2.7 | `CS2_RealWalking_LaneReader_v027_ManualScan.zip`、`RW-LITE-v027.txt` |
| v0.2.8 | `CS2_RealWalking_AimProbe_v028.zip`（尚无实机日志） |
| AutoWalk 路线方案 | `CS2_RealWalking_AutoWalk_Initial_Plan.md` |
| G0.1 | `RealWalking_G0_SourceRebuild.zip`、`BuildLog-G0.txt` |
| G0.2 | `RealWalking_G0_GetValueOrDefault_Fix_v02.zip`；本机 `PASS` 由用户消息反馈 |
| G1 / v0.3.0 | `RealWalking_G1_FPC_LaneBridge_v030.zip`、`RW-G1-Results.txt` |
| G1.1 / v0.3.1 | `RealWalking_G1_LaneDiagnosis_v031.zip`、`RW-G1-Results(1).txt` |
| G1.2 / v0.3.2 | `RealWalking_G1_NetSubLane_v032.zip`（尚无实机日志） |

**有关外部源码的参考（非本项目版权归属声明）：**

- First Person Camera Continued: <https://github.com/Cgameworld/FirstPersonCameraContinued>
- First Person Camera Continued 的旧/其他公开路径曾被讨论；**正式入库前需要核实实际使用的上游仓库、commit SHA、许可证文本和版本**。
- CS2 Modding Guide（搜索系统资料）：<https://ps1ke.github.io/Cities-Skylines-2-Modding-Guide/Game/Net/SearchSystem/>

**公开仓库的许可建议**：自行编写、授权为 MIT 的代码可以保留相应许可；若再分发修改后的 GPL FPC 源码/二进制，必须遵守相应 GPL 义务并保留原作者版权声明；不能仅因其他模组源码可浏览就视为允许复制。各来源的许可证与实际使用代码须逐项核对。

**隐私提示**：原始编译日志可能包含本机账户名、用户目录、个人文件夹名称或路径；GitHub 发布前建议脱敏。日志文本也可能包含城市/模组环境信息，上传前应审查。

## 8. 后续工作的可验证问题（不是功能承诺）

1. 先从游戏源码结构、Modding Guide、官方工具/开放代码实例中核对：
   - 普通道路的路侧人行道是否对应 `PedestrianLane`，其中心线位于何处；
   - 独立人行道、坡道、天桥、楼梯、地下通道以及地铁站台分别使用哪些 `Lane`、`ConnectionLane`、`SubLane`、`Area` 或其他 ECS 组件；
   - `GetLaneSearchTree` 与 `GetNetSearchTree` 各自索引的范围和过滤条件；
   - 何时需要读取实际可见几何表面而非仅使用寻路中心线。
2. 给每个场景建立**已知能让市民实际通行**的对照测试地图，记录位置、截图及游戏版本，避免混用镜头手动高度。
3. 如 G1.2 本机成功编译，再在独立步行路径与天桥上按同一流程核对 `NET-OWNERS` / `OWNER-PED`，而不是直接认定 `SubLane` 可解决全部场景。
4. 只有在稳定识别正确高度且不存在明显跳层风险后，才进入 G2 自动高度控制；优先以原版 FPC 为宿主、提供一键关闭和恢复模式。

---

## 9. 给外部读者的简短摘要

> Real Walking / AutoWalk 的这一研究分支尝试为《城市：天际线 II》的现成第一人称摄像机增加真实行人路径高度识别。2026年10月期间，我们通过 AI 辅助开发和用户本机实测，逐步确认了游戏的车道搜索 API、真实曲线读取、快捷键诊断和 FPC 运行时位置读取，并完成了 FPC C# 部分的轻量重编译。但是，目标天桥/路侧人行道的导航数据尚未正确匹配。当前版本仍为研究性诊断工具，不具备自动上下坡或正式自由步行功能。项目的下一步是基于可靠资料查明不同步行设施的真实导航数据类型，再决定是否继续推进 AutoWalk。
